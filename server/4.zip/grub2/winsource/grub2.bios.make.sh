allmods=" "
allmods=$allmods" biosdisk"
allmods=$allmods" fat"
allmods=$allmods" ntfs"
allmods=$allmods" part_gpt"
allmods=$allmods" part_msdos"
allmods=$allmods" search"
grub-mkimage --config=./grub2.bios.boot.sh --output=/tmp/g2kernel.img --format=i386-pc --verbose $allmods
cat /usr/lib/grub/i386-pc/lnxboot.img /tmp/g2kernel.img > /tmp/grub2win.boot.bios
rm  /tmp/g2kernel.img
echo
echo
ls -lad  /tmp/grub2win.boot.bios
echo
echo
