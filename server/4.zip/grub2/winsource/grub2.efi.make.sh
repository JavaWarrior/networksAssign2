allmods=" "
allmods=$allmods" fat"
allmods=$allmods" ntfs"
allmods=$allmods" part_gpt"
allmods=$allmods" part_msdos"
allmods=$allmods" search"
allmods=$allmods" ext2"
allmods=$allmods" echo"
allmods=$allmods" read"
allmods=$allmods" test"
allmods=$allmods" configfile"
allmods=$allmods" normal"
grub-mkimage --config=./grub2.efi.boot.sh --output=/tmp/grub2win.boot.efi --format=x86_64-efi --verbose $allmods
echo
echo
ls -lad  /tmp/grub2win.boot.efi
echo
echo

