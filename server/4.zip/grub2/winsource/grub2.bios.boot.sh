search -f /grub2/g2bootmgr/grub2win.boot.bios  --set=winaddress
set winpart=($winaddress)
set prefix=$winpart/grub2
set pager=1
