prefix=$cmdpath
clear
echo
echo Prefix from bootefi.sh is $prefix
configfile $prefix/grub2win.setup.cfg
echo
echo
